import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ChatClient {

  public static void main(String[] args) {

    String serverIP = args[0];
    int port = 5533;

    try {
      System.out.println("Connecting to server at " + serverIP + " on port " + port);
      Socket socket = new Socket(serverIP, port);
      System.out.println("Connection established successfully.");

      BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
      PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

      BufferedReader consoleInput = new BufferedReader(new InputStreamReader(System.in));

      String userInput;
      while ((userInput = consoleInput.readLine()) != null) {
        out.println(userInput);
        if (userInput.equalsIgnoreCase("adios")) {
          break;
        }

        String response = in.readLine();
        System.out.println("Servidor: " + response);
        if (response.equalsIgnoreCase("adios")) {
          break;
        }
      }

      in.close();
      out.close();
      socket.close();
      System.out.println("Closing client... OK");

    } catch (IOException e) {
      System.err.println("Error in client: " + e.getMessage());
    }
  }
}
