package uf3act1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class ChatServer {
    public static void main(String[] args) {
        int port = 5533; 

        try {
            ServerSocket serverSocket = new ServerSocket(port);
            System.out.println("Iniciando servidor... OK");

            Socket clientSocket = serverSocket.accept();
            System.out.println("Cliente conectado desde " + clientSocket.getInetAddress());

            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

            BufferedReader consoleInput = new BufferedReader(new InputStreamReader(System.in));

            String userInput;
            while ((userInput = in.readLine()) != null) {
                System.out.println("Cliente: " + userInput);
                if (userInput.equalsIgnoreCase("adios")) {
                    break;
                }

                System.out.print("Servidor: ");
                String response = consoleInput.readLine();
                out.println(response);
                if (response.equalsIgnoreCase("adios")) {
                    break;
                }
            }

            in.close();
            out.close();
            clientSocket.close();
            serverSocket.close();
            System.out.println("Cerrando servidor... OK");

        } catch (IOException e) {
            System.err.println("Error en el servidor: " + e.getMessage());
        }
    }
}

